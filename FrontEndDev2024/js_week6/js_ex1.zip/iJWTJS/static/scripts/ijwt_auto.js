import { iJWT } from "./ijwt.js";
const ijwt = new iJWT({ mode: "development" });
ijwt.update_dom();
