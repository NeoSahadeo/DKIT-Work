const x = "Hello";
const y = "World";

console.log(x + y);

// Output: HelloWorld
