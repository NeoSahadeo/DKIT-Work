# i Just Want Templating JS

iJWST.js is simple Javascript utility script
that lets me create simple HTML sites for my
uni projects.

# Documentation
