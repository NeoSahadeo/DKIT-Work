<title> About </title>
<p class="mx-auto my-auto mb-0 text-center text-2xl">
	音 (Oto) translates to "sound" in English.
	<br />
	Oto is a music platform where you can listen to music
	<br />
	that has been uploaded to my GitLab repository.
	<br />
	<br />
	A custom API has been written to retrieve and control songs from
	<br />
	the repository. The source code for the site is not
	<br />
	publicly available, and there are no plans to continue
	<br />
	the development of this site past 2024.
	<br />
	But while it's here, enjoy it!
</p>
<p class="mb-auto mt-14 text-center text-2xl italic">"Beautiful things don't ask for attention"</p>
