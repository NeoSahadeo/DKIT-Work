<script lang="ts">
	let { class: class_list = '' }: { class: string } = $props();

	let size = $state(0.7);
</script>

<div class={class_list}>
	<svg
		width={147 * size}
		xmlns="http://www.w3.org/2000/svg"
		height={64 * size}
		id="screenshot-41377df5-274f-80ce-8005-5a75593f68c9"
		viewBox="5751.5 3001 147 64"
		style="-webkit-print-color-adjust::exact"
		xmlns:xlink="http://www.w3.org/1999/xlink"
		fill="none"
		version="1.1"
	>
		<style>
		</style>
		<g id="shape-41377df5-274f-80ce-8005-5a75593f68c9">
			<g
				transform="matrix(1.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000)"
				class="text-container"
				x="5751.5"
				y="3001"
				width="147"
				height="64"
				rx="0"
				ry="0"
			>
				<defs>
					<pattern
						patternUnits="userSpaceOnUse"
						x="5751.5"
						y="3001"
						width="146.08433532714844"
						height="77.1084213256836"
						id="fill-0-render-943-0"
					>
						<g>
							<rect
								width="146.08433532714844"
								height="77.1084213256836"
								style="fill:#ffffff;fill-opacity:1"
							>
							</rect>
						</g>
					</pattern>
				</defs>
				<g class="fills" id="fills-41377df5-274f-80ce-8005-5a75593f68c9">
					<text
						x="5751.5"
						y="3071.168662548065"
						dominant-baseline="ideographic"
						textLength="146.08433532714844"
						lengthAdjust="spacingAndGlyphs"
						style="text-transform:none;font-family:&quot;Sirin Stencil&quot;;letter-spacing:normal;font-style:normal;font-weight:400;white-space:pre;font-size:53px;text-decoration:none solid rgb(255, 255, 255);direction:ltr;fill:#ffffff;fill-opacity:1"
						>音 Oto</text
					>
				</g>
			</g>
		</g>
	</svg>
</div>
