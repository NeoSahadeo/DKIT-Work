<svg
	width={25}
	xmlns="http://www.w3.org/2000/svg"
	height={25}
	id="screenshot-f252f7ce-4e09-8002-8005-570baeae0258"
	viewBox="3535.5 1934.5 36.183 36"
	style="-webkit-print-color-adjust::exact"
	xmlns:xlink="http://www.w3.org/1999/xlink"
	fill="none"
	version="1.1"
>
	<g id="shape-f252f7ce-4e09-8002-8005-570baeae0258" style="fill:#000000" rx="0" ry="0">
		<g id="shape-f252f7ce-4e09-8002-8005-570baeae0259">
			<g class="fills" id="fills-f252f7ce-4e09-8002-8005-570baeae0259">
				<ellipse
					cx="3548.3571428571427"
					cy="1947.3571428571427"
					rx="12.857142857142662"
					ry="12.857142857142662"
					transform="matrix(1.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000)"
					fill-rule="evenodd"
					fill="none"
					stroke-linejoin="round"
					style="fill:none"
				>
				</ellipse>
			</g>
			<g
				fill-rule="evenodd"
				fill="none"
				stroke-linejoin="round"
				id="strokes-f252f7ce-4e09-8002-8005-570baeae0259"
				class="strokes"
			>
				<g class="stroke-shape">
					<ellipse
						cx="3548.3571428571427"
						cy="1947.3571428571427"
						rx="12.857142857142662"
						ry="12.857142857142662"
						transform="matrix(1.000000, 0.000000, 0.000000, 1.000000, 0.000000, 0.000000)"
						style="fill:none;fill-opacity:none;stroke-width:1;stroke:#afafaf;stroke-opacity:1"
					>
					</ellipse>
				</g>
			</g>
		</g>
		<g id="shape-f252f7ce-4e09-8002-8005-570baeae025a">
			<g class="fills" id="fills-f252f7ce-4e09-8002-8005-570baeae025a">
				<path
					d="M3571.683,1970.500L3557.357,1956.357"
					fill-rule="evenodd"
					fill="none"
					stroke-linejoin="round"
					style="fill:none"
				>
				</path>
			</g>
			<g
				fill-rule="evenodd"
				fill="none"
				stroke-linejoin="round"
				id="strokes-f252f7ce-4e09-8002-8005-570baeae025a"
				class="strokes"
			>
				<g class="stroke-shape">
					<path
						d="M3571.683,1970.500L3557.357,1956.357"
						style="fill:none;fill-opacity:none;stroke-width:1;stroke:#afafaf;stroke-opacity:1"
					>
					</path>
				</g>
			</g>
		</g>
	</g>
</svg>
