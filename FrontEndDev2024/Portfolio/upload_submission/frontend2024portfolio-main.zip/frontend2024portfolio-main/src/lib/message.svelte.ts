import { notifications } from './shared.svelte';

export const send_message = () => {};

$effect(() => console.log(notifications));
