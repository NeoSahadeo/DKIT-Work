#!/bin/bash

# Header
#
#		Purpose: Build and zip the site for upload to mysql
#		Author: Neo Sahadeo
#
# Body

pnpm run build
zip -r oto build
